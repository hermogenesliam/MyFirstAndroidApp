
package com.hermogenes.studentinformationsystem;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;

public class MainActivity extends Activity {

    EditText username, password;
    EditText studentNo, lastName, firstName, middleName;
    EditText program, specialization, yearLevel;

    Button loginButton, saveButton, viewButton;

    LinearLayout loginLayout, studentLayout;

    ArrayList<String> students = new ArrayList<>();

    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = new DBHelper(this);
        showLoginScreen();
    }

    private void showLoginScreen() {
        ScrollView scroll = new ScrollView(this);
        loginLayout = new LinearLayout(this);
        loginLayout.setOrientation(LinearLayout.VERTICAL);
        loginLayout.setPadding(40, 40, 40, 40);

        TextView title = new TextView(this);
        title.setText("STUDENT INFORMATION SYSTEM");
        title.setTextSize(23);

        username = new EditText(this);
        username.setHint("Username");

        password = new EditText(this);
        password.setHint("Password");
        password.setInputType(129);

        loginButton = new Button(this);
        loginButton.setText("LOGIN");

        loginLayout.addView(title);
        loginLayout.addView(username);
        loginLayout.addView(password);
        loginLayout.addView(loginButton);

        scroll.addView(loginLayout);
        setContentView(scroll);

        loginButton.setOnClickListener(v -> {
            String user = username.getText().toString();
            String pass = password.getText().toString();

            if (user.equals("admin") && pass.equals("12345")) {
                showStudentScreen();
            } else {
                Toast.makeText(this,
                        "Invalid username or password",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void showStudentScreen() {

        ScrollView scroll = new ScrollView(this);

        studentLayout = new LinearLayout(this);
        studentLayout.setOrientation(LinearLayout.VERTICAL);
        studentLayout.setPadding(35, 30, 35, 30);

        TextView title = new TextView(this);
        title.setText("STUDENT INFORMATION");
        title.setTextSize(24);

        studentNo = new EditText(this);
        studentNo.setHint("Student Number");

        lastName = new EditText(this);
        lastName.setHint("Last Name");

        firstName = new EditText(this);
        firstName.setHint("First Name");

        middleName = new EditText(this);
        middleName.setHint("Middle Name");

        TextView academicTitle = new TextView(this);
        academicTitle.setText("STUDENT ACADEMIC INFORMATION");
        academicTitle.setTextSize(20);

        program = new EditText(this);
        program.setHint("Program");

        specialization = new EditText(this);
        specialization.setHint("Specialization (if any)");

        yearLevel = new EditText(this);
        yearLevel.setHint("Year Level");

        saveButton = new Button(this);
        saveButton.setText("SAVE STUDENT");

        viewButton = new Button(this);
        viewButton.setText("VIEW STUDENTS");

        studentLayout.addView(title);
        studentLayout.addView(studentNo);
        studentLayout.addView(lastName);
        studentLayout.addView(firstName);
        studentLayout.addView(middleName);

        studentLayout.addView(academicTitle);
        studentLayout.addView(program);
        studentLayout.addView(specialization);
        studentLayout.addView(yearLevel);

        studentLayout.addView(saveButton);
        studentLayout.addView(viewButton);

        scroll.addView(studentLayout);
        setContentView(scroll);

        saveButton.setOnClickListener(v -> saveStudent());

        viewButton.setOnClickListener(v -> viewStudents());
    }

    private void saveStudent() {

        String number = studentNo.getText().toString().trim();
        String last = lastName.getText().toString().trim();
        String first = firstName.getText().toString().trim();
        String middle = middleName.getText().toString().trim();
        String prog = program.getText().toString().trim();
        String spec = specialization.getText().toString().trim();
        String year = yearLevel.getText().toString().trim();

        if (number.isEmpty() || last.isEmpty()
                || first.isEmpty() || prog.isEmpty()
                || year.isEmpty()) {

            Toast.makeText(this,
                    "Please complete the required fields",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        boolean saved = dbHelper.insertStudent(
                number,
                last,
                first,
                middle,
                prog,
                spec,
                year
        );

        if (saved) {
            Toast.makeText(this,
                    "Student successfully saved!",
                    Toast.LENGTH_SHORT).show();

            clearFields();

        } else {
            Toast.makeText(this,
                    "Student not saved! Check database.",
                    Toast.LENGTH_SHORT).show();
        }

    }


    private void viewStudents() {

        android.database.Cursor cursor = dbHelper.getAllStudents();

        if (cursor == null || cursor.getCount() == 0) {

            if (cursor != null) {
                cursor.close();
            }

            Toast.makeText(this,
                    "No student records found",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder result = new StringBuilder();

        while (cursor.moveToNext()) {

            result.append("Student No: ")
                    .append(cursor.getString(1)).append("\n");

            result.append("Last Name: ")
                    .append(cursor.getString(2)).append("\n");

            result.append("First Name: ")
                    .append(cursor.getString(3)).append("\n");

            result.append("Middle Name: ")
                    .append(cursor.getString(4)).append("\n");

            result.append("Program: ")
                    .append(cursor.getString(5)).append("\n");

            result.append("Specialization: ")
                    .append(cursor.getString(6)).append("\n");

            result.append("Year Level: ")
                    .append(cursor.getString(7))
                    .append("\n\n--------------------\n\n");
        }

        cursor.close();

        new AlertDialog.Builder(this)
                .setTitle("STUDENT RECORDS")
                .setMessage(result.toString())
                .setPositiveButton("OK", null)
                .show();
    }


    private void clearFields() {
        studentNo.setText("");
        lastName.setText("");
        firstName.setText("");
        middleName.setText("");
        program.setText("");
        specialization.setText("");
        yearLevel.setText("");
    }
}
