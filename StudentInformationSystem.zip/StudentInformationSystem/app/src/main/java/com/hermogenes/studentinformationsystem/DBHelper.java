
package com.hermogenes.studentinformationsystem;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "StudentDB.db";
    private static final int DATABASE_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String query = "CREATE TABLE students (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "student_no TEXT UNIQUE, " +
                "last_name TEXT, " +
                "first_name TEXT, " +
                "middle_name TEXT, " +
                "program TEXT, " +
                "specialization TEXT, " +
                "year_level TEXT)";

        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS students");
        onCreate(db);
    }

    public boolean insertStudent(
            String number,
            String last,
            String first,
            String middle,
            String program,
            String specialization,
            String year) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("student_no", number);
        values.put("last_name", last);
        values.put("first_name", first);
        values.put("middle_name", middle);
        values.put("program", program);
        values.put("specialization", specialization);
        values.put("year_level", year);

        long result = db.insert("students", null, values);

        return result != -1;
    }

    public Cursor getAllStudents() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM students ORDER BY id DESC",
                null
        );
    }

    public Cursor searchStudent(String number) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM students WHERE student_no = ?",
                new String[]{number}
        );
    }
}
